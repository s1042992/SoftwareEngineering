package CC;

public interface IRocketSystemBase {
	void ignite(int x, int y);
	void shutoff(int x);
	void log(String str);
}
