package CC;

public class ILogger {
	
	public String content;
	
	public ILogger() {
		content = null;
	}
	
	public void setLog(String message){
		content = content + message;
	}
	
	public String getLog(){
		return content;
	}
}