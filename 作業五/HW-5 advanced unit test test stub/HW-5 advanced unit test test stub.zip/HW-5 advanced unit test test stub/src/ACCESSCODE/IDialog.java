package ACCESSCODE;

public interface IDialog {

	public int show();
	
}
