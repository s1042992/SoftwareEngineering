package ACCESSCODE;

public interface IDialog {

	public int show();
	void set(int x);
	
}
