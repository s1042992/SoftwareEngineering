package ACCESSCODE;

public class OoooSetTimeZoneDialog implements IDialog {
	public int show()
	{
		return 2;
	}
}
